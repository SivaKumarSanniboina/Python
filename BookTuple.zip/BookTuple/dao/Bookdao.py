from excep import BookNotFoundException


class Book_tuple(object):
    '''
    classdocs
    '''

    def __init__(self):
        self.__book_tuple = []

    def add_book_toTuple(self, bk_obj):
        self.__book_tuple.append(bk_obj)

    def read_book_tuple(self):
        return [item.__str__() for item in self.__book_tuple]
