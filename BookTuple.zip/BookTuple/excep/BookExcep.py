class BookNotFoundException(Exception):
    '''
    classdocs
    '''

    def __init__(self, errormessage="Book not found"):
        '''
        Constructor
        '''
        self.__errormessage = errormessage

    def __str__(self):
        return self.__errormessage
