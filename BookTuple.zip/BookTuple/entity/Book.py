class Book(object):
    '''
    classdocs
    '''

    def __init__(self, book_id, book_name, author_name, price):
        '''
        Constructor
        '''
        self.__book_id = book_id
        self.__book_name = book_name
        self.__author_name = author_name
        self.__price = price

    def get_book_id(self):
        return self.__book_id

    def get_book_name(self):
        return self.__book_name

    def get_author_name(self):
        return self.__author_name

    def get_price(self):
        return self.__price

    def set_book_id(self, value):
        self.__book_id = value

    def set_book_name(self, value):
        self.__book_name = value

    def set_author_name(self, value):
        self.__author_name = value

    def set_price(self, value):
        self.__price = value

    def del_book_id(self):
        del self.__book_id

    def del__book_name(self):
        del self.__book_name

    def del_author_name(self):
        del self.__author_name

    def del_price(self):
        del self.__price

    def __str__(self):
        return "Emp ID: " + self.get_book_id()+ " Emp Name: " + self.get_book_name()+ "Author Name: " + self.get_author_name() +"Price:" + self.get_price()

