from dao import Book_tuple

if __name__ == '__main__':
    thistuple1 =("B01","Java","James", "500")
    thistuple2={"B02","C","Denies Richie","400"}
    '''
    Tuple
    '''
    print("\n\nBook Tuple CRUD operation-----------------------")

    # Create_tuple
    print("\nAdding Books......:")
    Book_obj = Book_tuple()
    Book_obj.add_book_toTuple(thistuple1)
    Book_obj.add_book_toTuple(thistuple2)

    # Read_tuple
    print("\nReading from Books............")
    print(Book_obj.read_book_tuple())

    # Delete_tuple
    print("\nDeleting books ...........")
    del thistuple2
    print("\nReading Remaining Book............")
    print(Book_obj.read_book_tuple())

