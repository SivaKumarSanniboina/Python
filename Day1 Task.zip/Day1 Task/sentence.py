sentence =input("enter the sentence: ")
