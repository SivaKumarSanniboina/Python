prority = input('enter the prority:')
weight = int(input('enter the weight:'))
distance = int(input('enter the distance:'))

if prority == '1':
    if weight <100:
        if distance<50:
            print("dispatch by van")

elif prority =='0':
    if weight<=5:
        print("dispatch by bike")
    else:
        print("dipatch by lorry")
else:
    print("dispatch by train")