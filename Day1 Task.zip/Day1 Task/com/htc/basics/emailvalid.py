def email(str):
    length=len(str)
    ind=0
    us=str.find('_')
    at=str.find('@')
    at1=str.count('@')
    dot=str.find('.')
    dot1=str.count('.')
    if((str.startswith('.') or str.startswith('@')) or
            (not(str.endswith('m') or str.endswith('n'))) or
            (at1!=1) or (dot==at+1) or (us>at) or
            (not(length>=10 and length<=30))):
        return 1!=1
    else:
        return str==str
str=input('Enter the email id :')
p=email(str)
if p:
    print("Valid")
else:
    print("Invalid")