bill=2000
member=input('enter the membership:')
if(member=='premium member'):
    bill = bill * 20 / 100
    print("the premium member bill is", bill)
elif(member=='gold member'):
    bill = bill * 15 / 100
    print("the gold member bill is", bill)
elif(member=='silver member'):
    bill = bill * 10 / 100
    print("the silver member bill is", bill)
else:
    bill=bill*5/100
    print("the other member bill is", bill)