import psycopg2
import json
from openpyxl.reader.excel import load_workbook

book =load_workbook(r"C:/Users/HP PC/studentdetails.xlsx")


sheet=book["Sheet1"]
jsonFile = open("connection.json",)
jsonReader=json.load(jsonFile)
dbname= jsonReader["dbname"]
user= jsonReader["user"]
host=jsonReader["host"]
password=jsonReader["password"]
conn = psycopg2.connect("dbname='"+dbname+"' user='"+user+ "'host='"+host+"'password='"+password+"'")

cursor = conn.cursor()

query = """INSERT INTO student (studentid,studentname,age) VALUES (%s, %s, %s)"""
r=1
while(sheet.cell(r,1).value!=None):
    studentId = sheet.cell(r,1).value
    studentName = sheet.cell(r,2).value
    age = sheet.cell(r,3).value
    r+=1
    values = (studentId,studentName,age)
    cursor.execute(query, values)
values = []

for row in sheet.rows:
    for cell in row:
        values.append(cell.value)
print(values)
cursor.close()

conn.commit()

conn.close()

print("")
print("Load Operation Done..!!")
print("")