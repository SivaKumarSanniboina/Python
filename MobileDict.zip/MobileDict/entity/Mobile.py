class Mobile(object):
    '''
    classdocs
    '''

    def __init__(self, mobile_id, mobile_name,color,browse_Type):
        '''
        Constructor
        '''
        self.__mobile_id = mobile_id
        self.__mobile_name = mobile_name
        self.__color=color
        self.__browse_Type=browse_Type

    def get_mobile_id(self):
        return self.__mobile_id

    def get_mobile_name(self):
        return self.__mobile_name

    def get_color(self):
        return self.__color

    def get_browse_Type(self):
        return self.__browse_Type

    def set_mobile_id(self, value):
        self.__mobile_id = value

    def set_mobile_name(self, value):
        self.__mobile_name = value

    def set_color(self, value):
        self.__color = value

    def set_browse_Type(self, value):
        self.__browse_Type = value

    def del_mobile_id(self):
        del self.__mobile_id

    def del_mobile_name(self):
        del self.__mobile_name

    def del_color(self):
        del self.__color

    def del_browse_Type(self):
        del self.__browse_Type

    def __str__(self):
        return "Mobile ID: " + self.get_mobile_id() + " Mobile Name: " + self.get_mobile_name()+" Color :"+self.get_color()+"Browse Type :"+self.get_browse_Type()

