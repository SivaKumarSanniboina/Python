from excep.MobileExcep import MobileNotFoundException

class Mobile_Dict(object):
    '''
    classdocs
    '''

    def __init__(self):
        self.__mobile_dict = []

    def add_mobiles_toDict(self, mob_obj):
        self.__mobile_dict.append(mob_obj)

    def read_mobiles_Dict(self):
        return [item.__str__() for item in self.__mobile_dict]

    def update_mobiles_Dict(self, mob_obj, color):
        if mob_obj in self.__mobile_dict:
            mob_obj.set_color(color)

    def remove_mobiles_fromDict(self, mobile_id):
        flag = 0
        print(mobile_id)
        for mob in self.__mobile_dict:
            if mob.get_mobile_id.__eq__(mobile_id):
                print(mob)
                self.__mobile_dict.remove(mob)
                flag = 1
                break
        if (flag == 0):
            raise MobileNotFoundException()
