from dao import Mobile_Dict
from entity import Mobile
import logging



if __name__ == '__main__':
    dict={"mobile_id":"M01","mobile_name":"Vivo","color":"Black","browse_Type":"Smartph"}
    dict1 = {"mobile_id": "M01", "mobile_name": "Vivo", "color": "Black", "browse_Type": "Smartph"}
    '''
    DICT
    '''
    logging.basicConfig(filename="newfile.log",
                        format='%(asctime)s %(levelno)s %(message)s',
                        filemode='a',
                        level=logging.DEBUG)

    print("\n\nMOBILES Dict CRUD operation:\n----------------------------")
    logging.basicConfig(level=logging.DEBUG)

    logger = logging.getLogger()

    # Create_list
    print("\nAdding Mobiless to the dict:")
    mob_obj = Mobile_Dict()
    mob_obj.add_mobiles_toDict(dict)
    mob_obj.add_mobiles_toDict(dict1)

    # Read_list
    print("\nReading from Mobiless dict:")
    print(mob_obj.read_mobiles_Dict())


    # Update_list
    print("\nUpdating Dictionary..........")
    dict["Color"] = "Grey"
    print(mob_obj.read_mobiles_Dict())
    logger.info("updating the Dictionary...")

    print("\nDelete the Dictionary")
    dict1.clear()
    print(mob_obj.read_mobiles_Dict())

    logger.info("Deleteing the Dictionary...")


