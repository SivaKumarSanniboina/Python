class MobileNotFoundException(Exception):
    '''
    classdocs
    '''

    def __init__(self, errormessage="Mobile not found"):
        '''
        Constructor
        '''
        self.__errormessage = errormessage

    def __str__(self):
        return self.__errormessage
