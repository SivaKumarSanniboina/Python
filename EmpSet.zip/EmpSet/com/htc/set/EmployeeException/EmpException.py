class EmpNotFoundException(Exception):
    '''
    classdocs
    '''

    def _init_(self, errormessage="Employee not found"):
        '''
        Constructor
        '''
        self.__errormessage = errormessage

    def _str_(self):
        return self.__errormessage