from com.htc.set.EmployeeDao.EmployeeDAOList import Employee_Set

if __name__ == '__main__':
    Employee1 = {"E01", "Siva", "50000"}
    Employee2 = {"E02", "Nani"," 30000"}
    Employee3 = {"E03", "Raja", "10000"}

    '''
    SET
    '''
    print("\n\nEmployee Set CRUD operation:\n----------------------------")

    # Create_list
    print("\nAdding Employee to the set:")
    Employee_obj = Employee_Set()
    Employee_obj.add_employee_toSet(Employee1)
    Employee_obj.add_employee_toSet(Employee2)
    Employee_obj.add_employee_toSet(Employee3)

    # Read_set
    print("\nReading from Employee Set:")
    print(Employee_obj.read_employee_Set())

    print("\nDelete the Employee.......")
    Employee_obj.remove_employee_fromSet(Employee3)

    print("\nReading Remaining Employee SET............")
    print(Employee_obj.read_employee_Set())