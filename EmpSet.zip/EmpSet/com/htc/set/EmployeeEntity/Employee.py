class Employee(object):

    def __init__(self, emp_id, emp_name, emp_salary):
        '''
        Constructor
        '''
        self.__emp_id = emp_id
        self.__emp_name = emp_name
        self.__emp_salary = emp_salary

    def get_emp_id(self):
        return self.__emp_id

    def get_emp_name(self):
        return self.__emp_name

    def get_emp_salary(self):
        return self.__emp_salary

    def set_emp_id(self, value):
        self.__emp_id = value

    def set_emp_name(self, value):
        self.__emp_name = value

    def set_emp_salary(self, value):
        self.__emp_salary = value

    def del_emp_id(self):
        del self.__emp_id

    def del_emp_name(self):
        del self.__emp_name

    def del_emp_salary(self):
        del self.__emp_salary

    def _str_(self):
        return "Emp ID: " + self.get_emp_id() + " Emp Name: " + self.get_emp_name() + "Emp salary: " + self.get_emp_salary()