from com.htc.set.EmployeeException.EmpException import EmpNotFoundException

class Employee_Set(object):
    '''
    classdocs
    '''

    def __init__(self):
        self.__employee_Set = [ ]

    def add_employee_toSet(self, emp_id):
        self.__employee_Set .append(emp_id)

    def read_employee_Set(self):
        return [item.__str__() for item in self.__employee_Set ]


    def remove_employee_fromSet(self, emp_id):
        print(emp_id)
        try:
            if emp_id in self.__employee_Set :
                self.__employee_Set .remove(emp_id)
        except:
            raise EmpNotFoundException()