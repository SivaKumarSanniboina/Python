"""#create
thislist = ["E01", "Siva", "2000"]
print(thislist)

#Read
mylist = thislist.copy()
print(mylist)

#update
thislist[1]="Ravi"
print(thislist)

#delete
thislist.remove("2000")
print(thislist)"""

EmpId = ['E01','E02','E03']
EmpName =[' SSS',' RRR',' WWW']
EmpSal =['2000','3000','4000']

print("1  Add Employee ")
print("2  Delete Employee ")
print("3  Modify the Employee ")
print("4  Query the Employee ")
print("5  exit ")
type = int(input(" Please select: "))
while type>=1 and type<=5:
  if type==1:
    id = input(" Please enter the Emp id:")
    name = input(" Please enter the Emp name: ")
    pw = input(" Please enter user Salary: ")
    EmpId.append(EmpId)
    EmpName.append(EmpName)
    EmpSal.append(EmpSal)
    print(" Added successfully! ")
  elif type==2:

    id = input(" Please enter the Emp id:")
    if id in EmpId:

      index = EmpId.index(id)
      EmpId.pop(index)
      EmpName.pop(index)
      EmpSal.pop(index)
      print(" Delete the success ")
    else:
      print(" No deleted user found !")
  elif type==3:

    id = input(" Please enter the Empid id:")
    if id in EmpId:

      index = EmpId.index(id)
      EmpName[index]= input(" Please enter the Emp name :")
      EmpSal[index]= input(" Please enter the Emp salary :")
      print(" Modify the success ")
    else:
      print(" No modifications were found !")
  elif type==4:

    id = input(" Please enter the Emp id:")
    if id in EmpId:

      index = EmpId.index(id)
      print(" The Emp id:",EmpId[index])
      print(" The Emp name :",EmpName[index])
      print(" The Emp Salary  :",EmpSal[index])
    else:
      print(" No Emp was queried !")
  elif type==5:
    break
  type = int(input(" Please select: "))
else:
  print(" Incorrect input! ")