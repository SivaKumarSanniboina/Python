#pip install psycopg2
import psycopg2

try:
    conn = psycopg2.connect("dbname='Student' user='postgres' host='localhost' password='Sivakumar@1997'")
    print(conn)
except:
    print("Unable to connect to database")

