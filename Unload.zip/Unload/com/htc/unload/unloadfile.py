from openpyxl import Workbook
import psycopg2
import json
import logging
from openpyxl.reader.excel import load_workbook
logging.basicConfig(filename="newfile.log",
                    format='%(asctime)s %(levelno)s %(message)s',
                    filemode='a',
                    level=logging.DEBUG)
logger = logging.getLogger()

jsonFile = open("connection1.json", )
jsonReader=json.load(jsonFile)
dbname= jsonReader["dbname"]
user= jsonReader["user"]
host=jsonReader["host"]
password=jsonReader["password"]
conn = None


wb = Workbook()
sheet = wb.active
try:
    conn = psycopg2.connect(f"dbname='{dbname}' user='{user}' host='{host}' password='{password}'")
    print(conn)
    logger.info("Connected to the database")

except:
    print("Unable to connect to database")
    logger.error("Error in connecting to database")

try:
    cur = conn.cursor()
    cur.execute("select * from product")


    rows = cur.fetchall()

    print("Retrieved data")
    logger.info("Data retrieved from the database")
    i = 0
    for row in rows:
        sheet.append( row)

        i = i + 1


except Exception as ex:
    print("Error in fetching data", ex)
    logger.error("Error in fetching data")
finally:
    conn.close()
    wb.save('product_details.xlsx')
    logger.info("Excel File saved..........")